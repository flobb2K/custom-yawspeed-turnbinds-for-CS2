Step #1
Copy the turnbinds folder to [Drive]:\Program Files (x86)\Steam\steamapps\common\Counter-Strike Global Offensive\game\csgo\cfg!

Step #2
Modify the cfg\turnbinds\settings.cfg to setup the turnbinds!

Step #3
type "exec turnbinds/exec.cfg" in console!